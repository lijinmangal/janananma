from django import forms
from .models import Wholesaler, DailyPurchase
class WholesalerForm(forms.ModelForm):
    class Meta:
        model = Wholesaler
        fields = ['name']

class DailyPurchaseForm(forms.ModelForm):
    class Meta:
        model = DailyPurchase
        fields = ['wholesaler', 'previous_credit', 'bill_number', 'bill_amount', 'paid_amount']

class WholesalerForm(forms.ModelForm):
    class Meta:
        model = Wholesaler
        fields = ['name']
